BLOCKAI — Android kaynak prototipi (v0.1)

Bu ZIP, doğrudan kurulabilir APK değildir; Android Studio ile derlenecek kaynak projedir.
Bu çalışma ortamında Android SDK/Gradle indirme ve APK derleme doğrulanmadığı için APK diye sunulmuyor.

İçerik:
- Android başlangıç ekranı
- Android “diğer uygulamaların üzerinde göster” izni
- Minecraft üzerinde hareket ettirilebilir yüzen AI tuşu
- Basit sohbet ekranı

ŞU AN OLMAYAN:
- Gerçek AI servisine bağlantı henüz ekli değil.
- Otomatik ekran okuma/çeviri yok.
- DonutSMP canlı piyasa verisi yok.

Gerçek AI için sonraki aşamada HTTPS arka uç servisi kurulmalı. API anahtarı APK içine konmamalı.
Arka uç kurulmadan uygulama gerçek AI yanıtı vermez. Herhangi bir Minecraft sunucusunun kurallarını aşmaya çalışmaz.
Android 8+ hedeflenmiştir. Android 13+ bildirim izni gerekebilir; ekran üstü gösterim izni ayarlardan açılmalıdır.

Derleme: Android Studio'da bu klasörü açıp Gradle Sync, ardından Build APK.
