package com.blockai.assistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(16, 24, 39))
        }
        val title = TextView(this).apply {
            text = "BlockAI"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "Minecraft oynarken Türkçe AI yardımcın.\\n\\nİlk sürüm: yüzen tuş ve sohbet arayüzü. Gerçek AI için güvenli sunucu bağlantısı yapılandırılmalıdır."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val permission = Button(this).apply {
            text = "Ekranın üzerinde gösterme iznini aç"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val start = Button(this).apply {
            text = "Yüzen tuşu başlat"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startForegroundService(Intent(this@MainActivity, FloatingService::class.java))
                }
            }
        }
        val chat = Button(this).apply {
            text = "Sohbeti aç"
            setOnClickListener { startActivity(Intent(this@MainActivity, ChatActivity::class.java)) }
        }
        layout.addView(title); layout.addView(desc)
        layout.addView(permission); layout.addView(start); layout.addView(chat)
        setContentView(layout)
    }
}
