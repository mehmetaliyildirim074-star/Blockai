package com.blockai.assistant

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class ChatActivity : Activity() {
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18,18,18,18)
            setBackgroundColor(Color.rgb(16,24,39))
        }
        val title = TextView(this).apply {
            text = "BlockAI · Minecraft yardımcısı"
            textSize = 21f; setTextColor(Color.WHITE); setPadding(0,0,0,16)
        }
        transcript = TextView(this).apply {
            text = "Selam! İngilizce mesajı buraya yapıştırıp Türkçe açıklamasını isteyebilirsin.\\n\\nNot: AI sunucu adresi yapılandırılana kadar gerçek AI yanıtları etkin değildir."
            textSize = 16f; setTextColor(Color.WHITE); setPadding(12,12,12,12)
        }
        val scroll = ScrollView(this).apply { addView(transcript) }
        input = EditText(this).apply {
            hint = "Mesajı yaz veya yapıştır…"
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        val send = Button(this).apply {
            text = "Gönder"
            setOnClickListener { sendMessage() }
        }
        root.addView(title); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        root.addView(input); root.addView(send)
        setContentView(root)
    }
    private fun sendMessage() {
        val msg = input.text.toString().trim()
        if (msg.isEmpty()) return
        transcript.append("\\n\\nSen: $msg\\nBlockAI: ")
        input.setText("")
        // Deliberately no API key is embedded in the app. Configure a trusted HTTPS
        // backend endpoint in a later build before enabling live AI requests.
        transcript.append("Canlı AI bağlantısı henüz yapılandırılmadı. Bu sürüm arayüz prototipidir.")
    }
}
